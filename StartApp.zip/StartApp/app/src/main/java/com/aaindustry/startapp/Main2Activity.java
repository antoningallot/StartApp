package com.aaindustry.startapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {


    //Fonction à la création de l'activité qui renvoie un texte qui décrit les commandes possibles et affiche le background
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        String message = "Launch X -> Launch the application X \nUninstall X -> Uninstall the application X\nSearch X -> Search \"X\" on Google\nText X Y -> Send the message \"Y\" to X \nPhone X -> Call X";
        TextView textView = findViewById(R.id.textView);
        textView.setText(message);
    }
}
