package com.aaindustry.startapp;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displaySpeechRecognizer();
    }


    public void record (View view) {
        displaySpeechRecognizer();
    }
    public void sendMessage(View view) {
        Intent intent = new Intent(this, Main2Activity.class);
        String message = "X -> Launch the application X \nUninstall X -> Uninstall the application X\nSearch X -> Search \"X\" on Google\nText X Y -> Send the message \"Y\" to X ";
        intent.putExtra("help_message", message);
        startActivity(intent);
    }

    public String getPackNameByAppName(String name) {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> l = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        String packName = "";
        for (ApplicationInfo ai : l) {
            String n = (String)pm.getApplicationLabel(ai);
            if (n.contains(name) || name.contains(n)){
                packName = ai.packageName;
            }
        }

        return packName;
    }

    public String getPhoneNumber(String name, Context context) {
        String ret = null;
        String selection = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" like'%" + name +"%'";
        String[] projection = new String[] { ContactsContract.CommonDataKinds.Phone.NUMBER};
        Cursor c = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection, selection, null, null);
        if (c.moveToFirst()) {
            ret = c.getString(0);
        }
        c.close();
        if(ret==null)
            ret = "Unsaved";
        return ret;
    }

    private static final int SPEECH_REQUEST_CODE = 0;

    // Create an intent that can start the Speech Recognizer activity
    private void displaySpeechRecognizer() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
// Start the activity, the intent will be populated with the speech text
        startActivityForResult(intent, SPEECH_REQUEST_CODE);
    }

    // This callback is invoked when the Speech Recognizer returns.
// This is where you process the intent and extract the speech text from the intent.
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
            List<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String spokenText = results.get(0);
            Log.d("MyApp",spokenText);
            if(spokenText.startsWith("launch")){
                spokenText = spokenText.replaceFirst("launch ", "");
                Log.d("text",spokenText);
                String packageName = getPackNameByAppName(spokenText);
                Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
                if (i == null) {
                    Log.d("Erreur", "Pas d'application trouvée");
                /*
                i = new Intent(Intent.ACTION_MAIN);
                i.setData(Uri.parse("market://details?id=" + "com.whatsapp"));*/
                }
                else {
                    // We found the activity now start the activity
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
            }
            else if(spokenText.startsWith("uninstall")){
                spokenText = spokenText.replaceFirst("uninstall ", "");
                String packageName = getPackNameByAppName(spokenText);
                Uri packageURI = Uri.parse("package:"+packageName);
                Intent i = new Intent(Intent.ACTION_DELETE, packageURI);
                if (i == null) {
                    Log.d("Erreur", "Pas d'application trouvée");
                /*
                i = new Intent(Intent.ACTION_MAIN);
                i.setData(Uri.parse("market://details?id=" + "com.whatsapp"));*/
                }
                else {
                    // We found the activity now start the activity
                    startActivity(i);
                }
            }
            else if(spokenText.startsWith("search")){
                spokenText = spokenText.replaceFirst("search ", "");
                Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                intent.putExtra(SearchManager.QUERY, spokenText);
                startActivity(intent);
            }
            else if(spokenText.startsWith("text")){
                spokenText = spokenText.replaceFirst("text ", "");
                String[] nameAndText = spokenText.split(" ", 2);
                spokenText = nameAndText[1];
                String phoneNumber = getPhoneNumber(nameAndText[0], this);
                Log.d("Name",nameAndText[0]);
                Log.d("text",nameAndText[1]);
                Log.d("number",phoneNumber);
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + phoneNumber));
                intent.putExtra("sms_body", spokenText);
                startActivity(intent);
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
